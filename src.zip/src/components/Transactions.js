import React, { useState } from "react";
import API from "../services/api";

function Transactions() {
  const [id, setId] = useState("");
  const [transactions, setTransactions] = useState([]);

  const fetchTransactions = async () => {
    try {
      const res = await API.get(`/transactions/${id}`);
      setTransactions(res.data);
    } catch (error) {
      alert("Error fetching transactions ❌");
    }
  };

  return (
    <div>
      <h2>Transactions</h2>

      <input
        placeholder="Account ID"
        onChange={(e) => setId(e.target.value)}
      />

      <br /><br />

      <button onClick={fetchTransactions}>Get Transactions</button>

      <ul>
        {transactions.map((t) => (
          <li key={t.id}>
            {t.type} - ₹{t.amount}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Transactions;