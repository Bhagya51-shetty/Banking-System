import React, { useState } from "react";
import API from "../services/api";

function CreateAccount() {
  const [name, setName] = useState("");
  const [balance, setBalance] = useState("");

  const handleCreate = async () => {
    try {
      await API.post("/accounts", {
        name,
        balance,
      });
      alert("Account Created Successfully");
    } catch (error) {
      alert("Error creating account");
    }
  };

  return (
    <div>
      <h2>Create Account</h2>

      <input
        placeholder="Enter Name"
        onChange={(e) => setName(e.target.value)}
      />

      <input
        placeholder="Enter Balance"
        onChange={(e) => setBalance(e.target.value)}
      />

      <button onClick={handleCreate}>Create</button>
    </div>
  );
}

export default CreateAccount;