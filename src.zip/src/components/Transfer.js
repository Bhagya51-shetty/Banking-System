import React, { useState } from "react";
import API from "../services/api";

function Transfer() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [amount, setAmount] = useState("");

  const handleTransfer = async () => {
    try {
      await API.post(
        `/accounts/transfer?from=${from}&to=${to}&amount=${amount}`
      );
      alert("Transfer Successful ✅");
    } catch (error) {
      alert("Error in transfer ❌");
    }
  };

  return (
    <div>
      <h2>Transfer</h2>

      <input
        placeholder="From Account ID"
        onChange={(e) => setFrom(e.target.value)}
      />

      <br /><br />

      <input
        placeholder="To Account ID"
        onChange={(e) => setTo(e.target.value)}
      />

      <br /><br />

      <input
        placeholder="Amount"
        onChange={(e) => setAmount(e.target.value)}
      />

      <br /><br />

      <button onClick={handleTransfer}>Transfer</button>
    </div>
  );
}

export default Transfer;