import React, { useState } from "react";
import API from "../services/api";

function Deposit() {
  const [id, setId] = useState("");
  const [amount, setAmount] = useState("");

  const handleDeposit = async () => {
    try {
      await API.post(`/accounts/${id}/deposit?amount=${amount}`);
      alert("Deposit Successful ✅");
    } catch (error) {
      alert("Error in deposit ❌");
    }
  };

  return (
    <div>
      <h2>Deposit</h2>

      <input
        placeholder="Account ID"
        onChange={(e) => setId(e.target.value)}
      />

      <br /><br />

      <input
        placeholder="Amount"
        onChange={(e) => setAmount(e.target.value)}
      />

      <br /><br />

      <button onClick={handleDeposit}>Deposit</button>
    </div>
  );
}

export default Deposit;