import React, { useState } from "react";
import API from "../services/api";

function Withdraw() {
  const [id, setId] = useState("");
  const [amount, setAmount] = useState("");

  const handleWithdraw = async () => {
    try {
      await API.post(`/accounts/${id}/withdraw?amount=${amount}`);
      alert("Withdraw Successful 💸");
    } catch (error) {
      alert("Error in withdrawal ❌");
    }
  };

  return (
    <div>
      <h2>Withdraw</h2>

      <input
        placeholder="Account ID"
        onChange={(e) => setId(e.target.value)}
      />

      <input
        placeholder="Amount"
        onChange={(e) => setAmount(e.target.value)}
      />

      <button onClick={handleWithdraw}>Withdraw</button>
    </div>
  );
}

export default Withdraw;