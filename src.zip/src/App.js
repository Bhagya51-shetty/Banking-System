import React from "react";
import "./App.css";

import CreateAccount from "./components/CreateAccount";
import Deposit from "./components/Deposit";
import Withdraw from "./components/Withdraw";
import Transfer from "./components/Transfer";
import Transactions from "./components/Transactions";

function App() {
  return (
    <div>

      {/* 🔥 NAVBAR */}
      <div className="navbar">
        <span>🏦 MyBank</span>
        <span>Welcome User</span>
      </div>

      {/* 🔥 DASHBOARD */}
      <div className="container">

        <div className="grid">
          <div className="card">
            <CreateAccount />
          </div>

          <div className="card">
            <Deposit />
          </div>

          <div className="card">
            <Withdraw />
          </div>

          <div className="card">
            <Transfer />
          </div>

          <div className="card">
            <Transactions />
          </div>
        </div>

      </div>
    </div>
  );
}

export default App;