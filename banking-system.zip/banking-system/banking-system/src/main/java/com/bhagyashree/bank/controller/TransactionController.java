package com.bhagyashree.bank.controller;

import com.bhagyashree.bank.model.Transaction;
import com.bhagyashree.bank.repository.TransactionRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/transactions")
public class TransactionController {

    private final TransactionRepository repo;

    public TransactionController(TransactionRepository repo) {
        this.repo = repo;
    }

    @GetMapping("/{accountId}")
    public List<Transaction> getTransactions(@PathVariable Long accountId) {
        return repo.findByFromAccountIdOrToAccountId(accountId, accountId);
    }
}