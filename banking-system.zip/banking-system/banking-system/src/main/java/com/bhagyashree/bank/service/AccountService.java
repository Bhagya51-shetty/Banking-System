package com.bhagyashree.bank.service;

import com.bhagyashree.bank.model.Account;
import com.bhagyashree.bank.model.Transaction;
import com.bhagyashree.bank.repository.AccountRepository;
import com.bhagyashree.bank.repository.TransactionRepository;
import com.bhagyashree.bank.exception.ResourceNotFoundException;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AccountService {

    private final AccountRepository repo;
    private final TransactionRepository transactionRepo;

    public AccountService(AccountRepository repo, TransactionRepository transactionRepo) {
        this.repo = repo;
        this.transactionRepo = transactionRepo;
    }

    // ================== DEPOSIT ==================
    public Account deposit(Long id, double amount) {

        if (amount <= 0) {
            throw new RuntimeException("Amount must be greater than zero");
        }

        Account acc = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

        acc.setBalance(acc.getBalance() + amount);
        repo.save(acc);

        Transaction t = new Transaction();
        t.setToAccountId(id);
        t.setAmount(amount);
        t.setType("DEPOSIT");
        t.setTimestamp(LocalDateTime.now());
        transactionRepo.save(t);

        return acc;
    }

    // ================== WITHDRAW ==================
    public Account withdraw(Long id, double amount) {

        if (amount <= 0) {
            throw new RuntimeException("Amount must be greater than zero");
        }

        Account acc = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

        if (acc.getBalance() < amount) {
            throw new RuntimeException("Insufficient Balance");
        }

        acc.setBalance(acc.getBalance() - amount);
        repo.save(acc);

        Transaction t = new Transaction();
        t.setFromAccountId(id);
        t.setAmount(amount);
        t.setType("WITHDRAW");
        t.setTimestamp(LocalDateTime.now());
        transactionRepo.save(t);

        return acc;
    }

    // ================== TRANSFER ==================
    public String transfer(Long fromId, Long toId, double amount) {

        if (amount <= 0) {
            throw new RuntimeException("Amount must be greater than zero");
        }

        Account from = repo.findById(fromId)
                .orElseThrow(() -> new ResourceNotFoundException("Sender account not found"));

        Account to = repo.findById(toId)
                .orElseThrow(() -> new ResourceNotFoundException("Receiver account not found"));

        if (from.getBalance() < amount) {
            throw new RuntimeException("Insufficient Balance");
        }

        from.setBalance(from.getBalance() - amount);
        to.setBalance(to.getBalance() + amount);

        repo.save(from);
        repo.save(to);

        Transaction t = new Transaction();
        t.setFromAccountId(fromId);
        t.setToAccountId(toId);
        t.setAmount(amount);
        t.setType("TRANSFER");
        t.setTimestamp(LocalDateTime.now());
        transactionRepo.save(t);

        return "Transfer Successful";
    }
}