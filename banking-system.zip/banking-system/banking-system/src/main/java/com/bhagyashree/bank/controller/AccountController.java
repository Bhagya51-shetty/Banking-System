package com.bhagyashree.bank.controller;

import com.bhagyashree.bank.model.Account;
import com.bhagyashree.bank.repository.AccountRepository;
import com.bhagyashree.bank.service.AccountService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/accounts")
public class AccountController {

    private final AccountRepository repo;
    private final AccountService service;

    public AccountController(AccountRepository repo, AccountService service) {
        this.repo = repo;
        this.service = service;
    }

    @PostMapping
    public Account createAccount(@RequestBody Account account) {
        return repo.save(account);
    }

    @GetMapping
    public List<Account> getAllAccounts() {
        return repo.findAll();
    }

    @GetMapping("/{id}")
    public Account getAccount(@PathVariable Long id) {
        return repo.findById(id).orElseThrow();
    }

    // Deposit
    @PostMapping("/{id}/deposit")
    public Account deposit(@PathVariable Long id, @RequestParam double amount) {
        return service.deposit(id, amount);
    }

    // Withdraw
    @PostMapping("/{id}/withdraw")
    public Account withdraw(@PathVariable Long id, @RequestParam double amount) {
        return service.withdraw(id, amount);
    }

    // Transfer
    @PostMapping("/transfer")
    public String transfer(
            @RequestParam Long from,
            @RequestParam Long to,
            @RequestParam double amount) {

        return service.transfer(from, to, amount);
    }
}